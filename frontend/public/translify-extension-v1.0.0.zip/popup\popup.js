// Translify - Extension Popup Controller with Instant Visual Feedback

document.addEventListener('DOMContentLoaded', () => {
  const masterToggle = document.getElementById('masterToggle');
  const masterStatusText = document.getElementById('masterStatusText');
  const targetLangSelect = document.getElementById('targetLangSelect');
  const activeLangBadge = document.getElementById('activeLangBadge');
  const typeButtons = document.querySelectorAll('.type-btn');
  const translateNowBtn = document.getElementById('translateNowBtn');
  const statusDot = document.getElementById('statusDot');
  const engineBadgeText = document.getElementById('engineBadgeText');
  const openOptionsBtn = document.getElementById('openOptionsBtn');
  const optionsIconBtn = document.getElementById('optionsIconBtn');
  const toastBanner = document.getElementById('toastBanner');
  const toastMsg = document.getElementById('toastMsg');

  let currentSettings = {
    enabled: true,
    targetLang: 'hi',
    conversionType: 'smart',
    apiEngine: 'free',
    apiKey: ''
  };

  let toastTimer = null;

  chrome.runtime.sendMessage({ action: 'GET_SETTINGS' }, (settings) => {
    if (settings) {
      currentSettings = { ...currentSettings, ...settings };
      masterToggle.checked = currentSettings.enabled;
      targetLangSelect.value = currentSettings.targetLang || 'hi';
      updateActiveLangBadge(currentSettings.targetLang || 'hi');
      updateTypeButtons(currentSettings.conversionType || 'smart');
      updateStatusUI();
    }
  });

  masterToggle.addEventListener('change', () => {
    currentSettings.enabled = masterToggle.checked;
    saveSettings();
    showToast(masterToggle.checked ? 'Translation Engine Enabled ✓' : 'Translation Engine Disabled ✖');
  });

  targetLangSelect.addEventListener('change', () => {
    const selectedCode = targetLangSelect.value;
    const selectedText = targetLangSelect.options[targetLangSelect.selectedIndex].text;
    currentSettings.targetLang = selectedCode;

    updateActiveLangBadge(selectedCode);
    saveSettings();
    showToast(`Target language updated to ${selectedText}! ✓`);
  });

  typeButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      const type = btn.getAttribute('data-type');
      currentSettings.conversionType = type;
      updateTypeButtons(type);
      saveSettings();
      const modeLabels = { smart: 'Sentence Mode', transliterate: 'Phonetic Mode', translate: 'Paragraph Mode' };
      showToast(`Switched to ${modeLabels[type] || type}! ✓`);
    });
  });

  translateNowBtn.addEventListener('click', async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab && tab.id) {
      chrome.tabs.sendMessage(tab.id, { action: 'TRIGGER_TRANSLATE_NOW' }).catch(() => {});
      showToast('Translating active field now... ⚡');
    }
  });

  const openOptions = () => {
    if (chrome.runtime.openOptionsPage) {
      chrome.runtime.openOptionsPage();
    } else {
      window.open(chrome.runtime.getURL('options/options.html'));
    }
  };

  if (openOptionsBtn) openOptionsBtn.addEventListener('click', (e) => { e.preventDefault(); openOptions(); });
  if (optionsIconBtn) optionsIconBtn.addEventListener('click', (e) => { e.preventDefault(); openOptions(); });

  function updateActiveLangBadge(code) {
    if (activeLangBadge) {
      activeLangBadge.textContent = code.toUpperCase();
    }
  }

  function showToast(message) {
    if (!toastBanner || !toastMsg) return;
    toastMsg.textContent = message;
    toastBanner.classList.remove('hidden');

    if (toastTimer) clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      toastBanner.classList.add('hidden');
    }, 2400);
  }

  function updateTypeButtons(activeType) {
    typeButtons.forEach(btn => {
      if (btn.getAttribute('data-type') === activeType) {
        btn.classList.add('active');
      } else {
        btn.classList.remove('active');
      }
    });
  }

  function updateStatusUI() {
    if (!currentSettings.enabled) {
      masterStatusText.textContent = 'Disabled';
      masterStatusText.className = 'switch-status off';
      statusDot.className = 'dot';
      statusDot.style.background = '#ef4444';
      engineBadgeText.textContent = 'Translation OFF';
    } else {
      masterStatusText.textContent = 'Active & Ready';
      masterStatusText.className = 'switch-status';
      statusDot.className = 'dot green';
      statusDot.style.background = '#22c55e';
      if (currentSettings.apiKey || currentSettings.apiEngine === 'openai') {
        engineBadgeText.textContent = 'Engine: ChatGPT GPT-4o-mini';
      } else {
        engineBadgeText.textContent = 'Engine: Direct Neural Hybrid';
      }
    }
  }

  function saveSettings() {
    updateStatusUI();
    chrome.runtime.sendMessage({
      action: 'UPDATE_SETTINGS',
      settings: currentSettings
    });
  }
});
