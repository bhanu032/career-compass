// Translify - Pure Direct Sentence-by-Sentence Translation Service Worker

const DEFAULT_SETTINGS = {
  enabled: true,
  sourceLang: 'auto',
  targetLang: 'hi',
  conversionType: 'smart',
  mode: 'sentence',
  debounceMs: 1000,
  apiEngine: 'free',
  apiKey: '',
  blacklistedSites: []
};

const cache = new Map();
const MAX_CACHE = 1500;

chrome.runtime.onInstalled.addListener(async () => {
  const stored = await chrome.storage.sync.get(null);
  const updatedSettings = { ...DEFAULT_SETTINGS, ...stored };
  await chrome.storage.sync.set(updatedSettings);
});

function getCacheKey(text, source, target) {
  return `${source}:${target}:${text.trim().toLowerCase()}`;
}

function setCache(key, val) {
  if (cache.size >= MAX_CACHE) {
    cache.delete(cache.keys().next().value);
  }
  cache.set(key, val);
}

// Direct Sentence Translation via Google GTX Service
async function performSentenceTranslation(text, sourceLang, targetLang) {
  try {
    const sl = sourceLang === 'auto' ? 'auto' : sourceLang;
    const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=${encodeURIComponent(sl)}&tl=${encodeURIComponent(targetLang)}&dt=t&q=${encodeURIComponent(text)}`;
    const response = await fetch(url);
    if (response.ok) {
      const data = await response.json();
      if (data && data[0]) {
        const translatedText = data[0].map(item => item[0]).filter(Boolean).join('');
        if (translatedText) return translatedText;
      }
    }
  } catch (err) {
    console.warn('[Translify] Translation fetch error:', err);
  }
  return text;
}

// OpenAI ChatGPT Direct API Translation
async function performOpenAITranslation(text, sourceLang, targetLang, apiKey) {
  try {
    const res = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey.trim()}`
      },
      body: JSON.stringify({
        model: 'gpt-4o-mini',
        messages: [
          { role: 'system', content: `Translate sentence by sentence from ${sourceLang} to ${targetLang}. Return ONLY the final translated text.` },
          { role: 'user', content: text }
        ],
        temperature: 0.1
      })
    });
    if (res.ok) {
      const data = await res.json();
      const output = data.choices?.[0]?.message?.content?.trim();
      if (output) return output;
    }
  } catch (err) {
    console.warn('[Translify] OpenAI API error:', err);
  }
  return null;
}

// Pure Sentence-by-Sentence Converter
async function convertSentenceDirect(text, sourceLang, targetLang, settings) {
  if (!text || !text.trim()) return text;

  const cacheKey = getCacheKey(text, sourceLang, targetLang);
  if (cache.has(cacheKey)) {
    return cache.get(cacheKey);
  }

  // Priority 1: OpenAI ChatGPT API if Key is provided
  if (settings.apiKey && settings.apiKey.trim().startsWith('sk-')) {
    const aiResult = await performOpenAITranslation(text, sourceLang, targetLang, settings.apiKey);
    if (aiResult) {
      setCache(cacheKey, aiResult);
      return aiResult;
    }
  }

  // Priority 2: Direct Google Translate GTX Engine
  const directResult = await performSentenceTranslation(text, sourceLang, targetLang);
  setCache(cacheKey, directResult);
  return directResult;
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'TRANSLATE_TEXT') {
    chrome.storage.sync.get(DEFAULT_SETTINGS, async (settings) => {
      try {
        const result = await convertSentenceDirect(
          message.text,
          message.sourceLang || settings.sourceLang,
          message.targetLang || settings.targetLang,
          { ...settings, ...(message.settingsOverride || {}) }
        );
        sendResponse({ success: true, translation: result });
      } catch (err) {
        sendResponse({ success: false, error: err.toString() });
      }
    });
    return true;
  }

  if (message.action === 'GET_SETTINGS') {
    chrome.storage.sync.get(DEFAULT_SETTINGS, (s) => sendResponse(s));
    return true;
  }

  if (message.action === 'UPDATE_SETTINGS') {
    chrome.storage.sync.set(message.settings, () => {
      chrome.tabs.query({}, (tabs) => {
        tabs.forEach(tab => {
          if (tab.id) chrome.tabs.sendMessage(tab.id, { action: 'SETTINGS_CHANGED', settings: message.settings }).catch(() => {});
        });
      });
      sendResponse({ success: true });
    });
    return true;
  }
});

chrome.commands.onCommand.addListener(async (command) => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab || !tab.id) return;
  if (command === 'toggle-translation') {
    const s = await chrome.storage.sync.get(DEFAULT_SETTINGS);
    const updated = !s.enabled;
    await chrome.storage.sync.set({ enabled: updated });
    chrome.tabs.sendMessage(tab.id, { action: 'SETTINGS_CHANGED', settings: { ...s, enabled: updated } }).catch(() => {});
  } else if (command === 'trigger-translate-now') {
    chrome.tabs.sendMessage(tab.id, { action: 'TRIGGER_TRANSLATE_NOW' }).catch(() => {});
  }
});
