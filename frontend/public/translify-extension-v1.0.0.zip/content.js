// Translify - Live Real-Time Typing Translation Engine

(function () {
  'use strict';

  if (window.__TRANSLIFY_LOADED__) return;
  window.__TRANSLIFY_LOADED__ = true;

  let settings = {
    enabled: true,
    sourceLang: 'auto',
    targetLang: 'hi',
    conversionType: 'smart',
    mode: 'sentence',
    debounceMs: 600,
    showFloatingPill: true,
    blacklistedSites: []
  };

  let activeElement = null;
  let floatingPill = null;
  let languagePopover = null;
  let liveDebounceTimer = null;
  let pendingRequests = 0;
  let isInternalEdit = false;

  const LANGUAGES = [
    { code: 'hi', name: 'Hindi' },
    { code: 'es', name: 'Spanish' },
    { code: 'bn', name: 'Bengali' },
    { code: 'mr', name: 'Marathi' },
    { code: 'gu', name: 'Gujarati' },
    { code: 'ta', name: 'Tamil' },
    { code: 'te', name: 'Telugu' },
    { code: 'kn', name: 'Kannada' },
    { code: 'pa', name: 'Punjabi' },
    { code: 'ur', name: 'Urdu' },
    { code: 'fr', name: 'French' },
    { code: 'de', name: 'German' },
    { code: 'ja', name: 'Japanese' },
    { code: 'zh', name: 'Chinese' },
    { code: 'ar', name: 'Arabic' },
    { code: 'ru', name: 'Russian' },
    { code: 'pt', name: 'Portuguese' },
    { code: 'it', name: 'Italian' },
    { code: 'en', name: 'English' }
  ];

  chrome.runtime.sendMessage({ action: 'GET_SETTINGS' }, (res) => {
    if (res) {
      settings = { ...settings, ...res };
      init();
    }
  });

  chrome.runtime.onMessage.addListener((message) => {
    if (message.action === 'SETTINGS_CHANGED') {
      settings = { ...settings, ...message.settings };
      updatePillUI();
    } else if (message.action === 'TRIGGER_TRANSLATE_NOW') {
      const el = getActiveTargetElement();
      if (el) translateDirectSentence(el);
    }
  });

  function init() {
    if (isSiteBlacklisted()) return;

    document.addEventListener('focusin', handleFocusIn, true);
    document.addEventListener('focusout', handleFocusOut, true);
    document.addEventListener('keydown', handleKeyDown, true);
    document.addEventListener('input', handleInput, true);

    createFloatingPill();
  }

  function isSiteBlacklisted() {
    const currentHost = window.location.hostname;
    return (settings.blacklistedSites || []).some(domain => currentHost.includes(domain));
  }

  function isEditableElement(el) {
    if (!el) return false;
    if (el.disabled || el.readOnly) return false;

    const tag = (el.tagName || '').toLowerCase();
    if (tag === 'textarea' || tag === 'input') return true;
    if (el.isContentEditable || el.getAttribute('contenteditable') !== null) return true;

    if (el.classList?.contains('CodeMirror') || 
        el.classList?.contains('cm-content') || 
        el.classList?.contains('monaco-editor') ||
        el.closest?.('.CodeMirror, .cm-editor, .monaco-editor, [contenteditable], [role="textbox"]')) {
      return true;
    }

    return false;
  }

  function getActiveTargetElement() {
    if (activeElement && isEditableElement(activeElement)) return activeElement;

    const docFocus = document.activeElement;
    if (docFocus && isEditableElement(docFocus)) {
      activeElement = docFocus;
      return docFocus;
    }

    const editorInput = document.querySelector('.CodeMirror textarea, .cm-editor textarea, [role="textbox"]');
    if (editorInput && isEditableElement(editorInput)) {
      activeElement = editorInput;
      return editorInput;
    }

    return null;
  }

  function handleFocusIn(e) {
    if (isEditableElement(e.target)) {
      activeElement = e.target;
      positionFloatingPill(e.target);
    }
  }

  function handleFocusOut(e) {
    const el = e.target;
    if (settings.enabled && isEditableElement(el)) {
      setTimeout(() => {
        const current = getActiveTargetElement();
        if (current !== el) {
          const val = el.value || el.innerText || '';
          if (val.trim() && /[a-zA-Z]/.test(val)) {
            translateDirectSentence(el);
          }
        }
      }, 150);
    }

    setTimeout(() => {
      const current = getActiveTargetElement();
      if (!current && 
          !floatingPill?.contains(document.activeElement) && 
          !languagePopover?.contains(document.activeElement)) {
        hideFloatingPill();
      }
    }, 250);
  }

  // Live Real-Time Typing Listener
  function handleInput(e) {
    if (isInternalEdit || !settings.enabled) return;

    const el = getActiveTargetElement();
    if (!el) return;

    if (liveDebounceTimer) clearTimeout(liveDebounceTimer);
    liveDebounceTimer = setTimeout(() => {
      translateDirectSentence(el);
    }, settings.debounceMs || 600);
  }

  function handleKeyDown(e) {
    if (!settings.enabled) return;

    const el = getActiveTargetElement();
    if (!el) return;

    // Alt + T -> Instant Direct Sentence Translation
    if (e.altKey && (e.key === 't' || e.key === 'T')) {
      e.preventDefault();
      translateDirectSentence(el);
      return;
    }

    // Trigger translation on Enter or Shift + Enter with native line break
    if (e.key === 'Enter') {
      setTimeout(() => {
        translateDirectSentence(el);
      }, 40);
    }
  }

  function setNativeInputValue(el, val) {
    const proto = el.tagName === 'INPUT' ? window.HTMLInputElement.prototype : window.HTMLTextAreaElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, 'value')?.set;
    if (setter) {
      setter.call(el, val);
    } else {
      el.value = val;
    }
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }

  function getElementTextAndCursor(el) {
    if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
      return {
        text: el.value || '',
        cursorPos: el.selectionStart !== null ? el.selectionStart : (el.value || '').length
      };
    } else if (el.isContentEditable) {
      const sel = window.getSelection();
      let cursorPos = (el.innerText || '').length;
      if (sel.rangeCount > 0) {
        const range = sel.getRangeAt(0);
        const preRange = range.cloneRange();
        preRange.selectNodeContents(el);
        preRange.setEnd(range.endContainer, range.endOffset);
        cursorPos = preRange.toString().length;
      }
      return {
        text: el.innerText || el.textContent || '',
        cursorPos: cursorPos
      };
    }
    return null;
  }

  // --- LIVE REAL-TIME SENTENCE TRANSLATION ---
  async function translateDirectSentence(el) {
    const info = getElementTextAndCursor(el);
    if (!info || !info.text) return;

    const { text, cursorPos } = info;
    const beforeCursor = text.substring(0, cursorPos);

    const sentenceMatch = beforeCursor.match(/([a-zA-Z][a-zA-Z0-9\s,'"-]+)[.?!;\n]?$/);
    if (!sentenceMatch || !sentenceMatch[1] || !sentenceMatch[1].trim()) return;

    const sentenceText = sentenceMatch[1].trim();
    if (sentenceText.length < 2) return;

    const startIdx = beforeCursor.lastIndexOf(sentenceText);
    const endIdx = startIdx + sentenceText.length;

    setPillStatus('translating');
    pendingRequests++;

    try {
      const res = await new Promise((resolve) => {
        chrome.runtime.sendMessage({
          action: 'TRANSLATE_TEXT',
          text: sentenceText,
          sourceLang: settings.sourceLang,
          targetLang: settings.targetLang
        }, (r) => resolve(r));
      });

      if (res && res.success && res.translation && res.translation.trim() !== sentenceText) {
        const translated = res.translation.trim();
        isInternalEdit = true;
        try {
          if (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') {
            el.focus();
            const newFullText = text.substring(0, startIdx) + translated + text.substring(endIdx);
            setNativeInputValue(el, newFullText);
            const newCaret = startIdx + translated.length + (text.substring(endIdx).startsWith('\n') ? 1 : 0);
            el.setSelectionRange(newCaret, newCaret);
          } else if (el.isContentEditable) {
            el.focus();
            const newFullText = text.substring(0, startIdx) + translated + text.substring(endIdx);
            el.innerText = newFullText;
          }
          setPillStatus('success');
        } finally {
          setTimeout(() => { isInternalEdit = false; }, 50);
        }
      } else {
        setPillStatus('active');
      }
    } catch (err) {
      console.error('[Translify] Live translation error:', err);
      setPillStatus('error');
    } finally {
      pendingRequests = Math.max(0, pendingRequests - 1);
    }
  }

  // --- FLOATING CONTROL PILL UI ---
  function createFloatingPill() {
    if (document.getElementById('translify-type-pill')) return;

    floatingPill = document.createElement('div');
    floatingPill.id = 'translify-type-pill';
    floatingPill.className = 'translify-pill-hidden';
    floatingPill.innerHTML = `
      <div class="translify-pill-content">
        <span class="translify-pill-icon">✨</span>
        <span class="translify-pill-mode" id="translify-pill-type-btn" title="Click to cycle modes">LIVE ✨</span>
        <span class="translify-pill-lang" id="translify-pill-lang-btn" title="Click to change language">${settings.targetLang.toUpperCase()}</span>
        <span class="translify-pill-status" id="translify-pill-status">LIVE</span>
        <button class="translify-pill-action" id="translify-pill-translate-btn" title="Translate active input (Alt+T)">⚡</button>
      </div>
    `;

    document.body.appendChild(floatingPill);

    const typeBtn = floatingPill.querySelector('#translify-pill-type-btn');
    typeBtn.addEventListener('mousedown', (e) => {
      e.preventDefault();
      e.stopPropagation();
      cycleConversionType();
    });

    const langBtn = floatingPill.querySelector('#translify-pill-lang-btn');
    langBtn.addEventListener('mousedown', (e) => {
      e.preventDefault();
      e.stopPropagation();
      toggleLanguagePopover();
    });

    const translateBtn = floatingPill.querySelector('#translify-pill-translate-btn');
    translateBtn.addEventListener('mousedown', (e) => {
      e.preventDefault();
      e.stopPropagation();
      const el = getActiveTargetElement();
      if (el) translateDirectSentence(el);
    });

    createLanguagePopover();
  }

  function cycleConversionType() {
    const cycle = { smart: 'transliterate', transliterate: 'translate', translate: 'smart' };
    const newType = cycle[settings.conversionType] || 'smart';
    settings.conversionType = newType;
    updatePillUI();

    chrome.runtime.sendMessage({
      action: 'UPDATE_SETTINGS',
      settings: { conversionType: newType }
    });
  }

  function createLanguagePopover() {
    languagePopover = document.createElement('div');
    languagePopover.id = 'translify-type-popover';
    languagePopover.className = 'translify-popover-hidden';
    languagePopover.innerHTML = `
      <div class="translify-popover-header">Target Language</div>
      <div class="translify-popover-grid">
        ${LANGUAGES.map(lang => `
          <button class="translify-lang-opt ${lang.code === settings.targetLang ? 'selected' : ''}" data-code="${lang.code}">
            ${lang.name} (${lang.code.toUpperCase()})
          </button>
        `).join('')}
      </div>
    `;

    document.body.appendChild(languagePopover);

    languagePopover.addEventListener('mousedown', (e) => {
      const btn = e.target.closest('.translify-lang-opt');
      if (btn) {
        e.preventDefault();
        const code = btn.getAttribute('data-code');
        changeTargetLanguage(code);
        hideLanguagePopover();
      }
    });
  }

  function changeTargetLanguage(code) {
    settings.targetLang = code;
    updatePillUI();

    chrome.runtime.sendMessage({
      action: 'UPDATE_SETTINGS',
      settings: { targetLang: code }
    });
  }

  function toggleLanguagePopover() {
    if (!languagePopover) return;
    if (languagePopover.classList.contains('translify-popover-visible')) {
      hideLanguagePopover();
    } else {
      const rect = floatingPill.getBoundingClientRect();
      languagePopover.style.top = `${window.scrollY + rect.bottom + 6}px`;
      languagePopover.style.left = `${window.scrollX + Math.max(10, rect.right - 220)}px`;
      languagePopover.classList.remove('translify-popover-hidden');
      languagePopover.classList.add('translify-popover-visible');
    }
  }

  function hideLanguagePopover() {
    if (languagePopover) {
      languagePopover.classList.remove('translify-popover-visible');
      languagePopover.classList.add('translify-popover-hidden');
    }
  }

  function positionFloatingPill(targetEl) {
    if (!settings.showFloatingPill || !settings.enabled || !floatingPill) {
      hideFloatingPill();
      return;
    }

    const rect = targetEl.getBoundingClientRect();
    if (rect.width === 0 || rect.height === 0) {
      hideFloatingPill();
      return;
    }

    const pillTop = window.scrollY + rect.top - 28 > 0 ? window.scrollY + rect.top - 28 : window.scrollY + rect.bottom + 4;
    const pillLeft = window.scrollX + rect.right - 140;

    floatingPill.style.top = `${Math.max(10, pillTop)}px`;
    floatingPill.style.left = `${Math.max(10, pillLeft)}px`;
    floatingPill.classList.remove('translify-pill-hidden');
    floatingPill.classList.add('translify-pill-visible');

    updatePillUI();
  }

  function hideFloatingPill() {
    if (floatingPill) {
      floatingPill.classList.remove('translify-pill-visible');
      floatingPill.classList.add('translify-pill-hidden');
    }
    hideLanguagePopover();
  }

  function updatePillUI() {
    if (!floatingPill) return;

    const langBtn = floatingPill.querySelector('#translify-pill-lang-btn');
    if (langBtn) langBtn.textContent = settings.targetLang.toUpperCase();

    const typeBtn = floatingPill.querySelector('#translify-pill-type-btn');
    if (typeBtn) {
      if (settings.conversionType === 'smart') {
        typeBtn.textContent = '✨ LIVE';
      } else if (settings.conversionType === 'transliterate') {
        typeBtn.textContent = '🔤 PHONETIC';
      } else {
        typeBtn.textContent = '🌐 TRANSLATE';
      }
    }

    const statusEl = floatingPill.querySelector('#translify-pill-status');
    if (statusEl && pendingRequests === 0) {
      statusEl.textContent = settings.enabled ? 'LIVE' : 'OFF';
      statusEl.className = settings.enabled ? 'translify-pill-status on' : 'translify-pill-status off';
    }
  }

  function setPillStatus(state) {
    if (!floatingPill) return;
    const statusEl = floatingPill.querySelector('#translify-pill-status');
    if (!statusEl) return;

    if (state === 'translating') {
      statusEl.textContent = '...';
      statusEl.className = 'translify-pill-status translating';
    } else if (state === 'success') {
      statusEl.textContent = '✓';
      statusEl.className = 'translify-pill-status success';
      setTimeout(() => {
        if (pendingRequests === 0) updatePillUI();
      }, 1000);
    } else if (state === 'error') {
      statusEl.textContent = '!';
      statusEl.className = 'translify-pill-status error';
      setTimeout(() => {
        if (pendingRequests === 0) updatePillUI();
      }, 1200);
    } else {
      updatePillUI();
    }
  }
})();
