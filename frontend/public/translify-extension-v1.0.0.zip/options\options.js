// Polyglot Type - Options Controller with OpenAI ChatGPT Integration

document.addEventListener('DOMContentLoaded', () => {
  const apiEngine = document.getElementById('apiEngine');
  const apiKey = document.getElementById('apiKey');
  const targetLang = document.getElementById('targetLang');
  const mode = document.getElementById('mode');
  const debounceMs = document.getElementById('debounceMs');
  const debounceVal = document.getElementById('debounceVal');
  const blacklistedSites = document.getElementById('blacklistedSites');
  const saveBtn = document.getElementById('saveBtn');
  const saveStatus = document.getElementById('saveStatus');

  debounceMs.addEventListener('input', () => {
    debounceVal.textContent = `${debounceMs.value} ms`;
  });

  // Load stored settings
  chrome.runtime.sendMessage({ action: 'GET_SETTINGS' }, (settings) => {
    if (settings) {
      apiEngine.value = settings.apiEngine || (settings.apiKey ? 'openai' : 'free');
      apiKey.value = settings.apiKey || '';
      targetLang.value = settings.targetLang || 'hi';
      mode.value = settings.mode || 'space';
      debounceMs.value = settings.debounceMs || 1000;
      debounceVal.textContent = `${debounceMs.value} ms`;
      blacklistedSites.value = (settings.blacklistedSites || []).join('\n');
    }
  });

  // Save settings
  saveBtn.addEventListener('click', () => {
    const rawKey = apiKey.value.trim();
    const selectedEngine = apiEngine.value === 'openai' || rawKey.startsWith('sk-') ? 'openai' : apiEngine.value;
    const sites = blacklistedSites.value
      .split('\n')
      .map(s => s.trim().toLowerCase())
      .filter(Boolean);

    const newSettings = {
      apiEngine: selectedEngine,
      apiKey: rawKey,
      targetLang: targetLang.value,
      mode: mode.value,
      debounceMs: parseInt(debounceMs.value, 10),
      blacklistedSites: sites
    };

    chrome.runtime.sendMessage({ action: 'UPDATE_SETTINGS', settings: newSettings }, (res) => {
      if (res && res.success) {
        saveStatus.style.display = 'inline';
        setTimeout(() => {
          saveStatus.style.display = 'none';
        }, 2000);
      }
    });
  });
});
