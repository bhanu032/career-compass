@echo off
title USB Connection Diagnostic & Auto-Fix
cd /d "%~dp0"
echo ======================================================
echo       USB-C Connection Diagnostic & Fix Tool
echo ======================================================
echo.

set ADB_EXE="C:\Users\91637\AppData\Local\Android\Sdk\platform-tools\adb.exe"

echo [1/3] Checking if Windows Receiver is running...
tasklist /fi "imagename eq USBTextReceiver.exe" | find /i "USBTextReceiver.exe" >nul
if %ERRORLEVEL% equ 0 (
    echo    -> USBTextReceiver is RUNNING!
) else (
    echo    -> USBTextReceiver was not running. Starting it now...
    start "" "%~dp0bin\USBTextReceiver.exe"
    timeout /t 1 >nul
)

echo.
echo [2/3] Checking for connected USB device...
%ADB_EXE% devices
echo.

%ADB_EXE% get-state >nul 2>nul
if %ERRORLEVEL% equ 0 (
    echo    -> Phone DETECTED over USB!
    echo.
    echo [3/3] Setting up USB Reverse Port Tunnel (tcp:58888)...
    %ADB_EXE% reverse tcp:58888 tcp:58888
    echo.
    echo ======================================================
    echo  SUCCESS! Your phone app should now show [CONNECTED]!
    echo ======================================================
) else (
    echo    -> Phone is NOT detected yet.
    echo.
    echo  Please follow these quick steps:
    echo   1. Unplug and re-plug your USB-C cable.
    echo   2. On your phone: Go to Settings -> Developer Options -> Enable "USB Debugging".
    echo   3. Look at your phone screen: If a popup says "Allow USB debugging?", tap ALLOW.
    echo   4. Make sure USB connection mode is "File Transfer / MTP" (not Charge only).
)

echo.
echo Press any key to re-check connection...
pause >nul
goto :eof
