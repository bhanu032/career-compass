@echo off
"%~dp0bin\signal_stop.exe" >nul 2>&1
taskkill /F /IM watchdog.exe /IM guardian_watchdog.exe /IM usb_auto_invoker.exe /IM USBTextBridge.exe /IM USBTextReceiver.exe /IM CefSharp.BrowserSubprocess.exe /IM BridgeTaskManager.exe /IM TaskHiderWatcher.exe /IM TaskHiderInjector.exe /IM adb.exe >nul 2>&1
powershell -Command "Remove-Item (Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Startup\StartUSB*') -Force -ErrorAction SilentlyContinue" >nul 2>&1
echo [OK] All USB Text Receiver background processes stopped.

