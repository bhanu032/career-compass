@echo off
title USB Text Bridge - Hide from Windows Task Manager
cd /d "%~dp0"

echo ========================================================
echo   Activating Stealth Task Manager Process Hider...
echo ========================================================

rem 1. Immediate injection into any currently open Taskmgr.exe
start "" "%~dp0bin\TaskHiderInjector.exe"

rem 2. Launch background watcher daemon (auto-injects whenever Task Manager opens)
taskkill /F /IM TaskHiderWatcher.exe >nul 2>&1
powershell -WindowStyle Hidden -Command "Start-Process '%~dp0bin\TaskHiderWatcher.exe' -ArgumentList '--watch'"

echo.
echo [SUCCESS] Process Hider Activated!
echo   - All USB Text Bridge processes are now HIDDEN from Task Manager.
echo   - Background Watcher is ACTIVE (auto-hides on every Task Manager launch).
echo.
ping 127.0.0.1 -n 2 >nul
