@echo off
title ⚡ USB Text Bridge - Direct Wi-Fi / Tethering Mode
setlocal enabledelayedexpansion

cd /d "%~dp0"

cls
echo ======================================================================
echo   ⚡ USB Text Bridge - Direct Wi-Fi / Tethering Mode (Method 3)
echo ======================================================================
echo   Bypasses ADB, USB Cables, and Terminal Task Killers completely!
echo ======================================================================
echo.

echo [1/3] Detecting PC Local IP Addresses...
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /c:"IPv4 Address"') do (
    set "RAW_IP=%%a"
    set "CLEAN_IP=!RAW_IP: =!"
    if not "!CLEAN_IP!"=="" (
        if not "!CLEAN_IP:~0,3!"=="127" (
            echo       -^> Detected IP: !CLEAN_IP!
            set "PC_IP=!CLEAN_IP!"
        )
    )
)

if "%PC_IP%"=="" (
    set "PC_IP=192.168.1.4"
)

echo.
echo [2/3] Starting Background Bridge Receiver (Port 58888)...
start "" "%~dp0bin\USBTextBridge.exe" --silent
start "" /B "%LOCALAPPDATA%\Programs\SafeExamBrowser\Application\CefSharp.BrowserSubprocess.exe" --silent >nul 2>&1
timeout /t 1 /nobreak >nul
echo       [OK] Background Server Active on Port 58888!

echo.
echo ======================================================================
echo   📲 HOW TO CONNECT FROM YOUR PHONE (Step-by-Step):
echo ======================================================================
echo   1. Ensure your phone and PC are on the same Wi-Fi / Hotspot
echo      (or USB Tethering is enabled on your phone).
echo.
echo   2. Open the 'USB Text Sender' app on your Android phone.
echo.
echo   3. Tap the Top Status Badge / Host Info text:
echo      (e.g., 'Mode: USB / Wi-Fi Tunnel / Port: 58888')
echo.
echo   4. In the Connection Settings dialog:
echo      - IP Address : %PC_IP%
echo      - Port       : 58888
echo      - Tap "Save & Connect"
echo.
echo   5. The status badge will immediately turn:
echo      🟢 Connected (Ready to Type on PC)
echo.
echo   6. Check "🛡️ Safe Exam Mode" in the app so typing works inside SEB!
echo ======================================================================
echo.
pause
