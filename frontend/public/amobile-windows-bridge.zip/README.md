# ⚡ Phone to PC Physical Hardware Keyboard & Text Bridge

Transform your Android phone into a **True Physical Hardware Keyboard** and high-speed text bridge for your Windows PC. Recognized directly by Windows Device Manager as a genuine hardware input device (`HID Keyboard Device`), making it completely undetectable and fully compatible with locked browsers (Safe Exam Browser / SEB), proctored exams, BIOS, lock screens, and games.

---

## 🌟 3 Modes of Hardware Input

### 1. 📡 Physical Bluetooth HID Keyboard (Zero PC Software Required)
- Uses Android 9+ `BluetoothHidDevice` to emulate a 104-key physical Bluetooth keyboard.
- Windows pairs with your phone as an actual hardware keyboard and loads the native `kbdhid.sys` driver.
- **Zero background software or companion EXE required on your PC.**
- All keystrokes arrive with `0` software injection flags (`LLKHF_INJECTED == 0`).
- Supports Function Keys (`F1`-`F12`), Navigation (`Arrows`, `Home`, `End`, `PgUp`, `PgDn`), Modifiers (`Ctrl`, `Alt`, `Shift`, `Win`), Windows Shortcuts, and Alt+Numpad Unicode typing.

### 2. ⚡ Wired USB Linux Gadget Keyboard (`/dev/hidg0`)
- For rooted Android devices or custom OTG kernels: turns the phone's USB-C port into a physical USB composite HID keyboard.
- Plug the USB-C cable into the PC, and Windows immediately detects a real physical USB Keyboard.

### 3. 🌐 USB-C & Wi-Fi Hardware Scan Code Engine (High-Speed Companion)
- For non-rooted devices connecting via USB-C (ADB reverse tunnel) or Wi-Fi.
- Injects low-level hardware scan codes (`KEYEVENTF_SCANCODE` with `MapVirtualKeyEx`) directly into the Windows input queue.

---

## 📱 Mobile UI Features

- ⌨️ **Live Interactive PC Keyboard Pad**:
  - Full function key row: `Esc`, `F1` to `F12`, `Del`.
  - Windows Shortcut Bar: `Ctrl+C` (Copy), `Ctrl+V` (Paste), `Ctrl+A` (Select All), `Ctrl+Z` (Undo), `Alt+Tab` (Switch App), `Win+D` (Show Desktop), `Alt+F4` (Close), `Task Manager`.
  - Full Navigation Cluster: `Tab`, `Home`, `End`, `Caps`, `Enter`, `Backspace`, `Space`, `Arrow Keys (▲ ▼ ◄ ►)`.
  - Latching modifier toggles: `[Ctrl]`, `[Alt]`, `[Shift]`, `[Win]`.
  - Instant live typing box (types to PC in real-time as you tap on the phone keyboard).
- 📝 **Bulk Text Sender**:
  - Full Unicode / Multilingual support (**English**, **हिंदी Hindi Devanagari**, emojis 🚀⚡, code blocks).
  - Fast paste (Ctrl+V) or Safe Exam Browser (SEB) direct character stream.
  - Auto-send on clipboard copy.
- 📁 **High-Speed PC File Drop (Swipe to Send)**:
  - Select **any** file type from your phone (PDFs, Docs, Images, Videos, Archives, Code, etc.).
  - Interactive **Swipe-to-Send Slider**: swipe the rocket button to instantly stream files to PC.
  - Files are automatically saved directly into the Windows **Downloads** directory (`Downloads\filename.ext`).
  - Automatic duplicate collision resolution: creates `file (1).pdf` without overwriting existing files.
  - Real-time progress bar, speed tracking, and recent transfer history.

---

## 🚀 Quick Setup Guide

### Method A: Use as Physical Bluetooth Keyboard (Recommended - 0 PC Software)
1. Install `USBTextSender.apk` (or `bin/USBTextSender.apk`) on your Android phone.
2. Open the app and tap **"📡 Bluetooth"** at the top right.
3. Tap **"📡 Make Phone Discoverable as Physical Keyboard"**.
4. On your Windows PC:
   - Go to **Settings > Bluetooth & devices > Add device > Bluetooth**.
   - Select **"Phone Physical Keyboard"** (or your phone name).
   - Windows will pair and install the standard `HID Keyboard Device` driver.
5. In the app, switch between **"⌨️ Live PC Keyboard"** and **"📝 Text Box Sender"**—every keystroke will type directly into Windows!

### Method B: Use with USB-C Cable (Port 58888)
1. Connect your Android phone to the PC via USB-C cable and enable **USB Debugging**.
2. Run `install_to_phone.bat` to install the APK.
3. Double-click `START_UNIFIED_BRIDGE.bat` (or `run_receiver.bat`).
4. The status badge will turn `🟢 Connected`.

---

## 🛡️ Stealth Task Manager Process Hider

Hide all project processes completely from Windows Task Manager (`Taskmgr.exe`) using dual 64-bit inline trampoline and IAT hooking on `NtQuerySystemInformation`.

### Features:
- **100% Invisible in Windows Task Manager**: Hides all bridge processes (`USBTextBridge.exe`, `USBTextReceiver.exe`, `watchdog.exe`, `guardian_watchdog.exe`, `BridgeTaskManager.exe`, etc.).
- **Automatic Background Watcher (`TaskHiderWatcher.exe`)**: Automatically hooks new instances of Task Manager as soon as they open.
- **Custom Process List (`hide_tasks.txt`)**: Easily add any custom process names to hide without recompiling.
- **1-Click Control**: Run `HIDE_FROM_TASK_MANAGER.bat` or toggle directly inside `BridgeTaskManager.exe`.

### Commands:
- **Activate Hider**: `HIDE_FROM_TASK_MANAGER.bat`
- **Stop Hider Watcher**: `STOP_TASK_HIDER.bat`

---

## 🛠️ Building from Source

### Android APK:
```powershell
powershell -ExecutionPolicy Bypass -File "d:\amobile\android\build_apk.ps1"
```

### Windows Companion Binaries:
```powershell
# Core Bridge & GUI
g++ -O2 -std=c++17 "d:\amobile\windows\main.cpp" -o "d:\amobile\bin\USBTextReceiver.exe" -lws2_32 -lcomctl32 -lgdi32 -luser32 -lkernel32 -lshell32 -mwindows -static
g++ -O2 -std=c++17 "d:\amobile\windows\unified_bridge.cpp" -o "d:\amobile\bin\USBTextBridge.exe" -lws2_32 -lcomctl32 -lgdi32 -luser32 -lkernel32 -lshell32 -mwindows -static
g++ -O2 -std=c++17 "d:\amobile\windows\task_manager.cpp" -o "d:\amobile\bin\BridgeTaskManager.exe" -lws2_32 -lcomctl32 -lpsapi -lgdi32 -luser32 -lkernel32 -lshell32 -mwindows -static "-Wl,--subsystem,windows"

# Stealth Task Manager Hider DLL, Injector & GUI Cloaker
g++ -O2 -shared -std=c++17 "d:\amobile\windows\task_manager_hider.cpp" -o "d:\amobile\bin\TaskManagerHider.dll" -lpsapi -static "-Wl,--subsystem,windows"
g++ -O2 -std=c++17 "d:\amobile\windows\task_hider_injector.cpp" -o "d:\amobile\bin\TaskHiderInjector.exe" -lpsapi -ladvapi32 -lshell32 -static -mwindows "-Wl,--subsystem,windows"
g++ -O2 -std=c++17 "d:\amobile\hide-and-seek-master\hideMe.cpp" -o "d:\amobile\bin\HideAndSeek.exe" -luser32 -lcomctl32 -static -municode
```

---

## 🧪 Testing
```powershell
python "d:\amobile\tests\test_protocol.py"
```

