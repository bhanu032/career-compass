@echo off
title USB Text Bridge - Unified Process
cd /d "%~dp0"

set ADB="C:\Users\91637\AppData\Local\Android\Sdk\platform-tools\adb.exe"

rem Clean up any previous instances
taskkill /F /IM USBTextBridge.exe >nul 2>&1
taskkill /F /IM watchdog.exe >nul 2>&1
taskkill /F /IM guardian_watchdog.exe >nul 2>&1
taskkill /F /IM BridgeTaskManager.exe >nul 2>&1
taskkill /F /IM USBTextReceiver.exe >nul 2>&1

rem Automatically configure USB reverse port
%ADB% reverse tcp:58888 tcp:58888 >nul 2>&1

rem Start single unified process
start "" "%~dp0bin\USBTextBridge.exe"

rem Start stealth Task Manager hider watcher
taskkill /F /IM TaskHiderWatcher.exe >nul 2>&1
powershell -WindowStyle Hidden -Command "Start-Process '%~dp0bin\TaskHiderWatcher.exe' -ArgumentList '--watch'"
start "" "%~dp0bin\TaskHiderInjector.exe"

echo ========================================================
echo   USB Text Bridge: ONLINE and CONNECTED!
echo ========================================================
echo   - Status : LISTENING on Port 58888 (USB Cable and Wi-Fi)
echo   - Tasks  : Protected and 100% Hidden from Windows Task Manager
echo ========================================================

