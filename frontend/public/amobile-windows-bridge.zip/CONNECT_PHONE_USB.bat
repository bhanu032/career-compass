@echo off
title ⚡ USB Text Bridge - Phone USB Connector
cd /d "%~dp0"
set ADB="C:\Users\91637\AppData\Local\Android\Sdk\platform-tools\adb.exe"

echo ========================================================
echo   ⚡ USB Text Bridge - Active Phone Connector
echo ========================================================
echo.

echo [1/3] Checking connected phone via USB...
%ADB% devices -l
echo.

echo [2/3] Binding 0-Latency USB Reverse Tunnel (Port 58888)...
%ADB% reverse tcp:58888 tcp:58888
if %ERRORLEVEL% equ 0 (
    echo   ✓ Port 58888 successfully bound over USB-C cable!
) else (
    echo   [!] Note: Ensure phone is plugged in with USB Debugging enabled.
)
echo.

echo [3/3] Launching App on Phone...
%ADB% shell am start -n com.usbtext.sender/.MainActivity >nul 2>&1
echo.

echo ========================================================
echo   🟢 ALL READY! LIVE USB CONNECTION ESTABLISHED
echo ========================================================
echo   - You can now type in the app on your phone.
echo   - Text will type directly into your PC's active cursor.
echo ========================================================
echo.
pause
